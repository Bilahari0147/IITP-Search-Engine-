 // echo $title->item(0)->nodeValue;
   
  //the table by its tag name
 /*
  foreach($tables as $table)
  {
  $trs     =    $table->getElementsByTagName('tr');
  foreach($trs as $tr)
    { 
	   $as      =   $tr->getElementsByTagName('a');
	   //echo    $as.getAttribute('href').nodeValue ;
	   $x   =  $as->getAttribute('href');
       $txt  =   $x.nodeValue;
       //echo $hrefs->nodeValue.'<br />';
	 }
  }
*/ 


 /*
$p = $dom->getElementsByTagName('p');
$i = 0;
for ($i; $i < $p->length; $i++) {
//$attr = $a->item($i)->getAttribute('href');
$attrp = $p->item($i)->textContent;
echo $attrp . "</br>";
 }
 */
 //get all rows from the table
  //$rows = $tables->item(0)->getElementsByTagName('tr'); 
  
  
  
  // loop over the table rows
 /* foreach ($rows as $row) 
  { 
   // get each column by tag name
      $cols = $row->getElementsByTagName('td'); 
   // echo the values  
      echo $cols->item(0)->nodeValue.'<br />'; 
      echo $cols->item(1)->nodeValue.'<br />'; 
      echo $cols->item(2)->nodeValue;
    }*/ 
