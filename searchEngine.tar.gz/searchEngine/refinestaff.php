<font size="5">
<?php

$age=$_GET["age"];
//echo $age;
$gen=$_GET["gen"];
//echo $gen;
$depart=$_GET["depart"];
//echo $depart;
$des=$_GET["des"];
//echo $des;
$str=$_GET["str"];
//echo $str;
$chec = "Assistant_Professor";
//if($age==1&&$gen==1&&$depart==1&&$des==1)
//$result = mysqli_query($con,"SELECT * FROM staff_new where firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]' ");



$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$x =str_word_count($str);
$words = preg_split('/\s+|(?<=[,\.!\_?])|(?=[,\.!\?])/',$str) ;
$j=0;
$i = 0;
$arr=array();
while($j<$x)
{if($age==1&&$des==1&&$depart==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($age==1&&$depart==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where  designation = '".$des."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");
 
 else if($age==1&&$des==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where department =  '".$depart."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");
   
 else if($age==1&&$des==1&&$depart==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where gender =  '".$gen."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($age==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where   designation = '".$des."' and department =  '".$depart."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($age==1&&$des==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where gender =  '".$gen."' and department =  '".$depart."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($age==1&&$depart==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where designation =  '".$des."' and gender = '".$gen."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($age==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where designation =  '".$des."' and gender = '".$gen."' and department = '".$depart."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   "); 

 
 else if($des==1&&$depart==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($depart==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and designation = '".$des."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");
 
 else if($des==1&&$gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and department =  '".$depart."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");
   
 else if($des==1&&$depart==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and gender =  '".$gen."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($gen==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and designation = '".$des."' and department =  '".$depart."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($des==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and gender =  '".$gen."' and department =  '".$depart."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else if($depart==1)
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and designation =  '".$des."' and gender = '".$gen."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   ");

 else 
 $result = mysqli_query($con,"SELECT * FROM staffsearch where age<'".$age."' and age>'".$age."'-10 and designation =  '".$des."' and gender = '".$gen."' and department = '".$depart."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]')   "); 
 
 
 
 
 
 
 
 
 while($row = mysqli_fetch_array($result))
  {//if($row['firstname']==$_GET["staff_search"]||$row['lastname']==$_GET["staff_search"]||$row['designation']==$_GET["staff_search"]||$row['phone']==$_GET["staff_search"]||$row['emailid']==$_GET["staff_search"])
  { $y=$row['id'];
    if(isset($arr[$y]) != -1)
   {echo  "<br />";
   echo  "<br />";
  
   echo "<img border='0' src='staffimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   echo "<a href=\"$row[link]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:"." Dr.".$row['firstname'] . " " . $row['lastname']." </br>designation:"." ".$row['designation']." </br>phone no: 0612255".$row['phone']." </br>emailid: ".$row['emailid']."@iitp.ac.in";
   echo "<br /><br />";
   //echo "".$row['details']."";
   echo "<br />";
   $arr[$row['id']]=-1;
   $i=1;}
  }
  
  
  }
  $j++;
 } 
   if($i==0)
   {
   echo "<br/><br/><br/>requested data is does not exist";
   }  




/*
$con = mysql_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("search", $con);

$chec = "Assistant_Professor";
$che =  "Professor";

$sql;
if($q=="1")
$sql="SELECT * FROM staffsearch ";
else if($q=="2")
$sql="SELECT * FROM staffsearch WHERE designation = '".$chec."'  ";
else if($q=="3")
$sql="SELECT * FROM staffsearch WHERE designation =  '".$che."' ";

$result = mysql_query($sql);


while($row = mysql_fetch_array($result))
  {
   echo  "<br />";
  
   echo "<img border='0' src='staffimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   echo "<a href=\"$row[link]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:"." Dr.".$row['firstname'] . " " . $row['lastname']." </br>designation:"." ".$row['designation']." </br>phone no: 0612255".$row['phone']." </br>emailid: ".$row['emailid']."@iitp.ac.in";
   echo "<br /><br />";
  // echo "".$row['details']."";
   echo "<br />";
  }

mysql_close($con); */
?>
</font>