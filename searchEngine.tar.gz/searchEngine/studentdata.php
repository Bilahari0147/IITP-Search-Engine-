<?php

    $conn = mysql_connect("localhost", "root", "")  or die(mysql_error());
    mysql_select_db("search", $conn) or die(mysql_error());
    $q = strtolower($_GET["term"]);

	$return = array();
    $query = mysql_query("select *  from studentsearch where firstname like '%$q%' or lastname like '%$q%'  ") or die(mysql_error());   
	while ($row = mysql_fetch_array($query)) {
    	array_push($return,array('label'=>$row['firstname']." ".$row['lastname'],'value'=>$row['firstname']." ".$row['lastname']));
	}
	echo(json_encode($return));

?>