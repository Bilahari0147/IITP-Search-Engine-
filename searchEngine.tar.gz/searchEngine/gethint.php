
<?php

$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
//$x =str_word_count($_GET["staff_search"]);
//$words = preg_split('/\s+|(?<=[,\.!\?])|(?=[,\.!\?])/',$_GET["staff_search"]) ;
//$j=0;
//$i = 0;
$arr=array();


$result = mysqli_query($con,"SELECT * FROM staff_new ");

while($row = mysqli_fetch_array($result))
  {
     $a[] = $row['firstname'] ." <tr/>&nbsp ". $row['lastname']; ;
	 //$a[] = $row['lastname'];
     //$a[] = $row['designation']; 	  
   
  } 
 
  //get the q parameter from URL
$q=$_GET["q"];

//lookup all hints from array if length of q>0
if (strlen($q) > 0)
  {
  $hint="";
  for($i=0; $i<count($a); $i++)
    {
    if (strtolower($q)==strtolower(substr($a[$i],0,strlen($q))))
      {
       if ($hint=="")
        {
        $hint="<a href='" . 
        "http://localhost/staffsearch.php?staff_search=".$a[$i].  
        "' target='_blank'>" . 
        $a[$i]. "</a>";
        }
      else
        {
        $hint=$hint . "<br /><a href='" . 
          "http://localhost/staffsearch.php?staff_search=".$a[$i]. 
        "' target='_blank'>" . 
        $a[$i] . "</a>";
        }


	
		
      }
    }
  }

// Set output to "no suggestion" if no hint were found
// or to the correct values
if ($hint == "")
  {
  $response="no suggestion";
  }
else
  {
  $response=$hint;
  }

//output the response
echo $response;
   


?>