<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql="INSERT INTO feedback (name, email, feed)
VALUES
('$_POST[firstname]','$_POST[lastname]','$_POST[age]')";

if (!mysqli_query($con,$sql))
  {
 die('Error: ' . mysqli_error());
 }
echo "1 record added";

mysqli_close($con);
?>