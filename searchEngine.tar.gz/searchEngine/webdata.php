<?php

    $conn = mysql_connect("localhost", "root", "")  or die(mysql_error());
    mysql_select_db("search", $conn) or die(mysql_error());
    $q = strtolower($_GET["term"]);

	$return = array();
    $query = mysql_query("select *  from websearch where title like '%$q%' ") or die(mysql_error());   
	while ($row = mysql_fetch_array($query)) {
    	array_push($return,array('label'=>$row['title'],'value'=>$row['title']));
	}
	echo(json_encode($return));

?>


