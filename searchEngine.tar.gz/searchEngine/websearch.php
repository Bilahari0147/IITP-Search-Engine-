<!DOCTYPE html>
<html>
<body>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>web search</title>
	<link href="http://localhost/jquery-ui.css" rel="stylesheet" type="text/css" />

    <script src="http://localhost/jquery.min.js"></script>

    <script src="http://localhost/jquery-ui.js"></script>
<style>
body { 
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size:18px;
}

ul.ui-autocomplete {
	background: none repeat scroll 0 0 #E8E8E8;
	cursor: pointer;
	display: block;
	list-style-type: none;
	max-width: 1000px;
	padding: 0;
	position: relative;
	z-index: 1;
}

ul.ui-autocomplete li.ui-menu-item {
	padding:3px 5px;
}

ul.ui-autocomplete li.ui-menu-item:hover, 
ul.ui-autocomplete li.ui-state-hover:hover{
	background:#666;
}


</style>
    <script>
    $(function() {
        $( "#txtLanguage" ).autocomplete({
            source: "webdata.php",
            minLength: 1
        });
    });
    </script>

</head>
<body>

        <div>
     	<font size="5">
		<form method="get" action="http://localhost/websearch.php" style="width: 1828px">
	   
		<input type = "text" id="txtLanguage" class="txtLanguage" name = "web_search" placeholder="web search" style="width: 1000px; height: 50px; font-size:15pt; font-family:Arial;font-weight:bold;color:#9999FF" required="true" onkeyup="showResult(this.value)" autocomplete = "off"/> 
		<br/>
		<input type="radio" name="site" value="www" checked="checked">Www &nbsp&nbsp&nbsp
        <input type="radio" name="site" value="intranet">Intranet &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
         
		 	<input type="radio" name="string_type" value="1" checked="checked">Any Words &nbsp&nbsp&nbsp
        <input type="radio" name="string_type" value="2">All Words &nbsp&nbsp&nbsp
			<input type="radio" name="string_type" value="3">Exact Phrase<br/>
   	    </div>
		
       

     	</form>
		
		</font>
		<br/><br>
	</body>
</html>







<div id="menu" style="width:1000px;float:left;">

<font size="4">
<?php
error_reporting(0);
ini_set('max_execution_time', 10000); //300 seconds = 5 minutes



$inst=0;

function recursive($homelink,$passed) 
 {
 
 
 
 $dom = new DOMDocument();
   //$homelink = "http://172.16.1.3/~sriparna/";
  //load the html
    
  @$html = $dom->loadHTMLFile("$homelink");

  //discard white space 
  $dom->preserveWhiteSpace = false; 
 
  $tables = $dom->getElementsByTagName('table'); 
  $title  = $dom->getElementsByTagName('title'); 
$x =str_word_count($_GET["web_search"]);
$words = preg_split('/ +/',$_GET["web_search"]) ;
//echo $words[0];  
$a = $dom->getElementsByTagName('a');
$i = 0;
//echo $a->length."<br/>";
for ($i; $i < $a->length; $i++)
 {
$attr1 = $a->item($i)->getAttribute('href');
$attr2 = $a->item($i)->textContent;
//echo "<a href=\"$homelink"."$attr1\">$attr2</a>". "</br>";
$t = $homelink."/".$attr1;
//echo $t;
//$x = sizeof($words);
$wor =  preg_split('/\s+|(?<=[,\._!\?])|(?=[,\.!\?])/',$attr2) ; ;
$l = str_word_count($attr2);
$l = sizeof($wor); 
 $j=0;
   $k =0;
if($_GET["string_type"]!="3")   
{ for($j=0;$j<$x;$j++) 
  {  
     for($k=0;$k<$l;$k++)
	 { 
	 similar_text ( strtolower(@$wor[$k]) ,  strtolower($words[$j]),$percent  );
    // if (strtolower($words[$j])==strtolower(substr(@$wor[$k],0,strlen($words[$j]))))
    if($percent>70)
   {
   //echo "$attr2"."<br/>"."$passed"."<br/>" ;
   echo "<a href=\"$homelink.$attr1\">$attr2</a>"; //  <img border=\"0\" src=\"arrow.jpg\" alt=\"preview\" width=\"32\" height=\"32\">
   echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
   echo "<a href=\"$t\" target=\"iframe_a\" ><img border=\"0\" src=\"preview.jpg\" alt=\"preview\" width=\"60\" height=\"40\"></a>"."<br/><br/>" ;
   //echo "$passed";
   
     }
	}
	}
 }
 
 else
 {
   for($j=0;$j<$x;$j++) 
  {  
     for($k=0;$k<$l;$k++)
	 { 
	 //similar_text ( strtolower(@$wor[$k]) ,  strtolower($words[$j]),$percent  );
    if (strtolower($words[$j])==strtolower(substr(@$wor[$k],0,strlen($words[$j]))))
   // if($percent==100)
   {
   //echo "$attr2"."<br/>"."$passed"."<br/>" ;
   echo "<a href=\"$homelink.$attr1\">$attr2</a>"; //  <img border=\"0\" src=\"arrow.jpg\" alt=\"preview\" width=\"32\" height=\"32\">
   echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
   echo "<a href=\"$t\" target=\"iframe_a\" ><img border=\"0\" src=\"preview.jpg\" alt=\"preview\" width=\"60\" height=\"40\"></a>"."<br/><br/>" ;
   //echo "$passed";
     $inst++;    
	}
	}
	} 
 
 }

if(($a->length)<=0||($attr1=="?C=N;O=D")||($attr1=="?C=M;O=A")||($attr1=="?C=S;O=A")||($attr1=="?C=D;O=A")||($attr1=="/")||($attr2=="Name")||($attr1==$passed))
{
//break; 
 }
else
{//echo "$attr1" ;
//if(! @ file_get_contents($t))
{
//if (strtolower($attr1)==strtolower(substr($attr1,0,strlen($base))))
recursive($attr1,$attr1); 
}
//else
{
recursive($t,$attr1);
}


}

 }
 
//$text = $dom->textContent;
//echo $text;
 
}

function internet($homelink) 
 {
 
 
 
 $dom = new DOMDocument();
   //$homelink = "http://172.16.1.3/~sriparna/";
  //load the html
    $che=0;
  @$html = $dom->loadHTMLFile("$homelink");

  //discard white space 
  $dom->preserveWhiteSpace = false; 
 
  //$tables = $dom->getElementsByTagName('table'); 
  $info  = $dom->getElementById('info'); 
$x =str_word_count($_GET["web_search"]);
$words = preg_split('/ +/',$_GET["web_search"]) ;
//echo $words[0];  

$a = @$info->getElementsByTagName('a');
$i = 0;
//echo $a->length."<br/>";
for ($i; $i < $a->length; $i++)
 {
$attr1 = $a->item($i)->getAttribute('href');
$attr2 = $a->item($i)->textContent;
//echo "<a href=\"$homelink"."$attr1\">$attr2</a>". "</br>";

//echo $t;

$wor =  preg_split('/\s+|(?<=[,\._!\?])|(?=[,\.!\?])/',$attr2) ; ;
$l = str_word_count($attr2);
  $j=0;
   $k =0; 
// for($j=0;$j<$x;$j++) 
  {  
    
    // if (strtolower($words[$j])==strtolower(substr(@$wor[$k],0,strlen($words[$j]))))
   //echo "$attr2"."<br/>"."$passed"."<br/>" ;
   echo "<a href=\"http://www.iitp.ac.in/"."$attr1\">$attr2</a>";
  
   echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
   echo "<a href=\"http://www.iitp.ac.in/"."$attr1\" target=\"iframe_a\" ><img border=\"0\" src=\"preview.jpg\" alt=\"preview\" width=\"60\" height=\"40\"></a>"."<br/><br/>" ;
   //echo "$passed";
   $che++;
	}

   
	
}

 
if($che==0)
{
echo " check search mode is correct or not<br/><br/>";
echo " Your search " .$_GET["web_search"] ."did not match any documents<br/><br/>";
echo " Make sure that all words are spelled correctly.<br/>
     Try different keywords.<br/>
     Try more general keywords.<br/>
     Try fewer keywords.<br/>"
	;
echo "<br><br>";
//echo "<a href=\""."$row[link]\" >$row[title]</a>";
}

 
 
//$text = $dom->textContent;
//echo $text;
 
}






$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$x =str_word_count($_GET["web_search"]);
if($x==0)
$x=1;
$words = preg_split('/ +/',$_GET["web_search"]) ;
$j=0;
$i = 0;
$no = 0;
//$x = sizeof($words);
$arr=array();
while($j<$x)
{

if(@$_GET["site"]=="intranet")
{
$result = mysqli_query($con,"SELECT * FROM websearch where title SOUNDS LIKE '$words[$j]' or link SOUNDS LIKE '$words[$j]' OR title REGEXP '$words[$j]' or link REGEXP '$words[$j]'  ");

while($row = mysqli_fetch_array($result))
  {//if($row['firstname']==$_GET["staff_search"]||$row['lastname']==$_GET["staff_search"]||$row['designation']==$_GET["staff_search"]||$row['phone']==$_GET["staff_search"]||$row['emailid']==$_GET["staff_search"])
  { $y=$row['id'];
    if(isset($arr[$y]) != -1)
   {echo  "<br />";
   echo  "<br />";
    $inst++;
   //echo "<img border='0' src='staffimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   if($row['title'] != $words[$j])
   echo "showing results for ".$row["title"]." instead of ". $words[$j]."<br/>";
   echo "<a href=\"$row[link]\" >$row[title]</a>";
    echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
   echo "<a href=\"$row[link]\" target=\"iframe_a\" ><img border=\"0\" src=\"preview.jpg\" alt=\"preview\" width=\"60\" height=\"40\"></a>"."<br/><br/>" ;
     //echo "name:"." Dr.".$row['firstname'] . " " . $row['lastname']." </br>designation:"." ".$row['designation']." </br>phone no: 0612255".$row['phone']." </br>emailid: ".$row['emailid']."@iitp.ac.in";
   recursive($row["link"],"?C=D;O=A");
   $inst++;
   $arr[$row['id']]=-1;
   $i=1;
   $no++;
   }
  }
  
  
  }
 
}
$j++;
}



if(($no==0)&&(@$_GET["site"]=="intranet"))
 {
$result = mysqli_query($con,"SELECT * FROM websearch ");
   while($row = mysqli_fetch_array($result))
  {
 
   recursive($row["link"],"?C=D;O=A");
   
   }
 
 }

if(@$_GET["site"]=="www")
 {if(@$_GET["string_type"]=="1")
  internet("http://www.iitp.ac.in/index.php/search.html?searchword=".$_GET["web_search"]."&ordering=&searchphrase=any");
  else if(@$_GET["string_type"]=="2")
  internet("http://www.iitp.ac.in/index.php/search.html?searchword=".$_GET["web_search"]."&ordering=&searchphrase=all");
  else 
  internet("http://www.iitp.ac.in/index.php/search.html?searchword=".$_GET["web_search"]."&ordering=&searchphrase=exact");
  $inst++;
 } 


 /*
   if($i==0)
   {$j=0;
    while($j<$x)
  {	
   $result = mysqli_query($con,"SELECT * FROM websearch where title REGEXP '$words[$j]' or link REGEXP '$words[$j]'  ");                
   while($row = mysqli_fetch_array($result))
 {
   
  {
   recursive($row["link"]);  
  }
  $j++;
 }
 }
}*/ 
if($inst==0)
{
echo " check search mode is correct or not<br/><br/>";
echo " Your search " .$_GET["web_search"] ."did not match any documents<br/><br/>";
echo " Make sure that all words are spelled correctly.<br/>
     Try different keywords.<br/>
     Try more general keywords.<br/>
     Try fewer keywords.<br/>"
	;
echo "<br><br>";
//echo "<a href=\""."$row[link]\" >$row[title]</a>";
}
    
?>
</font>


</div>

<div "width:800px;">
<iframe  name="iframe_a" width="880" height="950"></iframe>
</div>


</body>
</html>