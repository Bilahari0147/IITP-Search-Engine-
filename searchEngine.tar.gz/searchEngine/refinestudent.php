<font size="5">
<?php
//batch,branch,gender,dicipline,hostel
//$age=$_GET["age"];
$batch =  $_GET["batch"];
//echo $batch;
$branch=$_GET["branch"];
//echo $gen;
$dicipline=$_GET["dicipline"];
//echo $depart;
$gender=$_GET["gender"];
//echo $des;
$hostel=$_GET["hostel"];

$str=$_GET["str"];
//echo $str;
$chec = "Assistant_Professor";
//echo "batch=".$batch."gen ".$gender."dic ".$dicipline."hos ".$hostel."bran ".$branch;
//if($age==1&&$gen==1&&$depart==1&&$des==1)
//$result = mysqli_query($con,"SELECT * FROM student_new where firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]' ");



$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$x =str_word_count($str);
$words = preg_split('/\s+|(?<=[,\.!\_?])|(?=[,\.!\?])/',$str) ;
$j=0;
$i = 0;
$arr=array();
while($j<$x)
{ //echo "oiedbcoicb";
 if($batch==1&&$branch==1&&$gender==1&&$dicipline==1&&$hostel==1)
 $result = mysqli_query($con," SELECT * FROM studentsearch where firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]'  ");

 
 else if($batch==1&&$branch==1&&$gender==1&&$dicipline==1)
 {$result = mysqli_query($con,"SELECT * FROM studentsearch where  hostel = '".$hostel."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
   //echo $hostel;
  }
  else if($batch==1&&$branch==1&&$gender==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 else if($batch==1&&$branch==1&&$hostel==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
  
  else if($batch==1&&$gender==1&&$hostel==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  branch = '".$branch."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
  
  else if($branch==1&&$gender==1&&$hostel==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  batch = '".$batch."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
  
   
   
   
   
  else if($branch==1&&$gender==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  batch = '".$batch."' and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
   else if($branch==1&&$gender==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  batch = '".$batch."' and dicipline='".$dicipline."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($dicipline==1&&$gender==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  batch = '".$batch."' and branch='".$branch."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
  else if($dicipline==1&&$branch==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  batch = '".$batch."' and gender='".$gender."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
 
 else if($dicipline==1&&$batch==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  branch = '".$branch."' and gender='".$gender."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($dicipline==1&&$batch==1&&$gender==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  branch = '".$branch."' and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
   else if($hostel==1&&$batch==1&&$gender==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  branch = '".$branch."' and dicipline='".$dicipline."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
  else if($hostel==1&&$batch==1&&$branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."' and dicipline='".$dicipline."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($dicipline==1&&$batch==1&&$branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."' and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
  else if($gender==1&&$batch==1&&$branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
 
 
 
 
 
 
 
 
 
  else if($batch==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and gender='".$gender."' and branch='".$branch."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
   else if($batch==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  branch = '".$branch."' and gender='".$gender."' and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($branch==1&&$batch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where dicipline = '".$dicipline."' and gender='".$gender."'and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
  else if($gender==1&&$batch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where dicipline = '".$dicipline."' and branch='".$branch."'and hostel='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
 
 else if($gender==1&&$branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and batch='".$batch."'and hostel ='".$hostel."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
  else if($branch==1&&$hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and batch='".$batch."'and gender='".$gender."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
   else if($dicipline==1&&$branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  hostel = '".$hostel."' and batch='".$batch."'and gender='".$gender."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
  else if($dicipline==1&&$gender==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  hostel = '".$hostel."' and batch='".$batch."'and branch='".$branch."' and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($hostel==1&&$gender==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and batch='".$batch."'and branch='".$branch."'  and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
  else if($hostel==1&&$dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."' and batch='".$batch."' and branch='".$branch."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
 
 
 
 
 
 
  else if($hostel==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."' and batch='".$batch."' and branch='".$branch."'and dicipline='".$dicipline."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 
 
  else if($dicipline==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  gender = '".$gender."' and batch='".$batch."' and branch='".$branch."'and hostel='".$hostel."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
  else if($gender==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and batch='".$batch."' and branch='".$branch."'and hostel='".$hostel."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 
 else if($batch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and gender='".$gender."' and branch='".$branch."'and hostel='".$hostel."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 
 else if($branch==1)
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and gender='".$gender."' and batch='".$batch."'and hostel='".$hostel."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 else
 $result = mysqli_query($con,"SELECT * FROM studentsearch where  dicipline = '".$dicipline."' and branch = '".$branch."'and gender='".$gender."' and batch='".$batch."'and hostel='".$hostel."'and ( firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]')   ");
 
 while($row = mysqli_fetch_array($result))
  {//if($row['firstname']==$_GET["staff_search"]||$row['lastname']==$_GET["staff_search"]||$row['rollno']==$_GET["staff_search"]||$row['phone']==$_GET["staff_search"]||$row['emailid']==$_GET["staff_search"])
  { $y=$row['id'];
    if(isset($arr[$y]) != -1)
   {echo  "<br />";
   echo  "<br />";
  
   //echo "<img border='0' src='staffimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   //echo "<a href=\"$row[link]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:".$row['firstname'] . " " . $row['lastname']." </br>rollno: "." ".$row['rollno']." </br> branch: ".$row['branch']." </br>emailid: ".$row['firstname']."@iitp.ac.in<br/>decipline:".$row['dicipline']." </br>hostel:" .$row['hostel'];
   echo "<br/><br/>";
   //echo "".$row['details']."";
   echo "<br />";
   $arr[$row['id']]=-1;
   $i=1;}
  }
  
  
  }
 
 
 

  
  $j++;
  }
  
  
   if($i==0)
   {
   echo "<br/><br/><br/>requested data is does not exist";
   }  




/*
$con = mysql_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("search", $con);

$chec = "Assistant_Professor";
$che =  "Professor";

$sql;
if($q=="1")
$sql="SELECT * FROM studentsearch ";
else if($q=="2")
$sql="SELECT * FROM studentsearch WHERE rollno = '".$chec."'  ";
else if($q=="3")
$sql="SELECT * FROM studentsearch WHERE rollno =  '".$che."' ";

$result = mysql_query($sql);


while($row = mysql_fetch_array($result))
  {
   echo  "<br />";
  
   echo "<img border='0' src='studentimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   echo "<a href=\"$row[link]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:"." Dr.".$row['firstname'] . " " . $row['lastname']." </br>rollno:"." ".$row['rollno']." </br>phone no: 0612255".$row['phone']." </br>emailid: ".$row['emailid']."@iitp.ac.in";
   echo "<br /><br />";
  // echo "".$row['details']."";
   echo "<br />";
  }

mysql_close($con); */
?>
</font>