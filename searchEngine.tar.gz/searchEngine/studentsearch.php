<!DOCTYPE html>



<html xmlns="http://www.w3.org/1999/xhtml">
<body>
<head runat="server">
    <title>student search</title>
	<link href="http://localhost/jquery-ui.css" rel="stylesheet" type="text/css" />

    <script src="http://localhost/jquery.min.js"></script>

    <script src="http://localhost/jquery-ui.js"></script>
<style>
body { 
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size:13px;
}

ul.ui-autocomplete {
	background: none repeat scroll 0 0 #DADADA;
	cursor: pointer;
	display: block;
	list-style-type: none;
	max-width: 600px;
	padding: 0;
	position: relative;
	z-index: 1;
}

ul.ui-autocomplete li.ui-menu-item {
	padding:3px 5px;
}

ul.ui-autocomplete li.ui-menu-item:hover, 
ul.ui-autocomplete li.ui-state-hover:hover{
	background:#666;
}


</style>


<head>
<style type="text/css">
.style9 {
	font-family: Andalus;
	font-size: large;
	font-weight: bold;
	font-style: normal;
	color: #0000FF;
	background-color:#FFFFFF;
	
}
</style>


<style >

.style1 {
   color:#FFFFFF;
   font-size:17px;
   width: 700px;
   height: 1000px;
   margin: 100px;
   margin-top:20px;
   font-weight: bold;
}



.style2 {
   background-color:#000099;   
   position: absolute;
   width:340px;
   padding: 0 0 0px 0; /*top right bottom left*/
   margin-top:50px;
   margin: 5px;
   font-weight: normal;}
</style>

</head>

    <script>
    $(function() {
        $( "#txtLanguage" ).autocomplete({
            source: "studentdata.php",
            minLength: 1
        });
    });
    </script>
<style>
#apDiv7 {
	position:absolute;
	left:44px;
	top:0px;
	width:197px;
	height:74px;
	layer-background-color:#FFFFFF;
	border:1px none #000000;
	z-index:3;
}
#apDiv4 {
	position:absolute;
	left:10px;
	top:px;
	width:1265px;
	height:169px;
	layer-background-color:#FFFFFF;
	border:1px none #000000;
	z-index:2;
}
#apDiv3 {
	position:absolute;
	left:353px;
	top:2px;
	width:50px;
	height:50px;
	z-index:1;
	visibility: inherit;
}
</style>
</head>


<div id="apDiv4">
 <div id="apDiv3">
<form method="get" action="http://localhost/studentsearch.php" >
<div class="ui-widget">
<input  id="txtLanguage" class="txtLanguage" type="text" name = "student_search" autocomplete = "off" placeholder="enter student's details here" style="width: 380px; height: 38px" onkeyup="showHint(this.value)">
</div>
</form>
</div>
<div id="apDiv7"><a href="student.html"><img src="images/iitpstudent_b.png" width="250" height="70"  /></a></div>
</div>
<!--
<div >
    <input id="txtLanguage" class="txtLanguage"/>
</div>
-->








<div style="margin-left: 30%;">
<div id="txtHint" style= "width:50%;float:left;">
 

<font size="5">
<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$x =str_word_count($_GET["student_search"]);
$words = preg_split('/\s+|(?<=[,_\.!\?])|(?=[,\.!\?])/',$_GET["student_search"]) ;
$j=0;
$i = 0;
$arr=array();
while($j<$x)
{
$result = mysqli_query($con,"SELECT * FROM studentsearch where firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or rollno REGEXP '$words[$j]' ");

while($row = mysqli_fetch_array($result))
  {//if($row['firstname']==$_GET["student_search"]||$row['lastname']==$_GET["student_search"]||$row['designation']==$_GET["student_search"]||$row['phone']==$_GET["student_search"]||$row['emailid']==$_GET["student_search"])
  { $y=$row['id'];
    if(isset($arr[$y]) != -1)
   {echo  "<br />";
   echo  "<br />";
  
   //echo "<img border='0' src='studentimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   //echo "<a href=\"$row[link]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:".$row['firstname'] . " " . $row['lastname']." </br>dicipline:"." ".$row['dicipline']." </br>branch:".$row['branch']."</br>hostel:".$row['hostel']." </br>emailid: ".$row['firstname']."@iitp.ac.in";
   echo "<br /><br />";
   //echo "".$row['details']."";
   echo "<br />";
   $arr[$row['id']]=-1;
   $i=1;}
  }
  
  
  }
  $j++;
 } 
   if($i==0)
   {
   echo "<br/><br/><br/>requested data is does not exist";
   }  
?>
</font>
</div>
</div>



<script>

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        vars[key] = value;
    });
    return vars;
}

var str = getUrlVars()["student_search"];

function showUser(batch,branch,gender,dicipline,hostel)
{
 //document.write(str);
if (batch=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","refinestudent.php?batch="+batch+"&branch="+branch+"&gender="+gender+"&dicipline="+dicipline+"&hostel="+hostel+"&str="+str,true);
xmlhttp.send();
}
</script>
<span class="style1">
<span class="style2"><br><span  style="color:#E6FFE6;font-weight:500;font-size:20px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Advance Search
</span>
  
<div "width:800px">
 <form>
 <br>

 
 
 
 <table>
<tr>
 <div class='selectBox'><th><span>Discipline</span></th>
	<th>    <span>: </span>	<select class="selectOptions" name="dicipline"  onchange="showUser(batch.value,branch.value,gender.value,dicipline.value,hostel.value)">
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="btech">btech</option>
				<option class="selectOption" value="mtech">mtech</option>			
			
			   
			</select></th>
		    </div>
		  
	    
 

 
 
 
 
 

 
<tr><tr><tr><tr>
<tr>
    <div class='selectBox'><span><th>Branch</th></span>
			<th><span>: </span><select class="selectOptions" name="branch"  onchange="showUser(batch.value,branch.value,gender.value,dicipline.value,hostel.value)" >
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="cse">cse</option>
				<option class="selectOption" value="ee">ee</option>
				<option class="selectOption" value="me">me</option>			   
			</select></th>
		    </div>
			</tr>
			 



	<tr><tr><tr><tr>
	<tr>
		  
   <div class='selectBox'><span><th>Batch</th></span></th>
	    	<th><span>: </span><select class="selectOptions" name="batch"  onchange="showUser(batch.value,branch.value,gender.value,dicipline.value,hostel.value)">
			   <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="2010">2010</option>
				<option class="selectOption" value="2011">2011</option>
				<option class="selectOption" value="2012">2012</option>
				<option class="selectOption" value="2013">2013</option>
			</select></th>
		    </div>	</tr>
			

     
	
	 <tr><tr><tr><tr><tr>
    <div class='selectBox'><span><th>Gender</th></span>
	    	<th><span>: </span><select class="selectOptions" name="gender"  onchange="showUser(batch.value,branch.value,gender.value,dicipline.value,hostel.value)">
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="male">male</option>			
				<option class="selectOption" value="female">female</option>		
			</select></th>
		    </div>	  </tr>
	
			<tr><tr><tr><tr><tr>
	<div class='selectBox'><span><th>Hostel</th></span>
	    	<th><span>: </span><select class="selectOptions" name="hostel"  onchange="showUser(batch.value,branch.value,gender.value,dicipline.value,hostel.value)">
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="Chanakya">Chanakya</option>
				<option class="selectOption" value="Ashoka">Ashoka</option>				
				<option class="selectOption" value="Newboyshostel">Newboyshostel</option>		
			   <option class="selectOption" value="Aryabhatta">Aryabhatta</option>		
			   <option class="selectOption" value="Girlshostel">Girlshostel</option>		
			</select></th>
		    </div></tr>
			</table>
<br>

	
	
	
	
</form>	
 	    
</div>
</span>
</span>


</body>
</html> 