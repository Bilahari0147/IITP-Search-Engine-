<!DOCTYPE html>
<html>

<body>


<form action="feed.php" method="post">
<input type="text" name="name" placeholder="enter name " ><br>
<br><textarea name="feed" style="height: 165px; width: 1021px" placeholder="enter your feed back"></textarea>
<input type="submit">
</form>



<?php

if(isset($_POST['submit'])) 
            { 
               // Putting data from form into variables to be manipulated 
               $pname = $_POST['name']; 
               $pfeed = $_POST['feed'];  
                   
               $conn = mysql_connect("localhost","root","") or die ("Can't connect"); 
               mysql_select_db("your_db",$conn);        
               // Getting the form variables and then placing their values into the MySQL table 
               mysql_query("INSERT INTO blog (pname, pfeed) VALUES ('".mysql_real_escape_string($pname)."', '".mysql_real_escape_string($pfeed)."')"); 
            }  
?>



<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$result = mysqli_query($con,"SELECT * FROM feedback");
$i = 0;
while($row = mysqli_fetch_array($result))
  {
  echo $row['name'] . "                " . $row['feed'];
    
  echo "<br />";
  
  
  }
  
?>




</body>
</html> 