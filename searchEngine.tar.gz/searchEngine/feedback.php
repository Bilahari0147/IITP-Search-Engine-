<html>
<body>
<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$sql=$sql="INSERT INTO feedback (name, email, feed)
VALUES
('$_POST[name]','$_POST[email]','$_POST[feedback]')";;

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error());
  }
echo "feedback successfully submitted";

mysqli_close($con);
?>
</body>
</html>