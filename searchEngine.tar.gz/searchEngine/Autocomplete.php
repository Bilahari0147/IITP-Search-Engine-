<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>JQuery autocomplete example with database accessing</title>
	<link href="http://localhost/jquery-ui.css" rel="stylesheet" type="text/css" />

    <script src="http://localhost/jquery.min.js"></script>

    <script src="http://localhost/jquery-ui.js"></script>
<style>
/*body { 
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
	font-size:13px;
}

ul.ui-autocomplete {
	background: none repeat scroll 0 0 #DADADA;
	cursor: pointer;
	display: block;
	list-style-type: none;
	max-width: 200px;
	padding: 0;
	position: relative;
	z-index: 1;
}

ul.ui-autocomplete li.ui-menu-item {
	padding:3px 5px;
}

ul.ui-autocomplete li.ui-menu-item:hover, 
ul.ui-autocomplete li.ui-state-hover:hover{
	background:#666;
}
*/

</style>
    <script>
    $(function() {
        $( "#txtLanguage" ).autocomplete({
            source: "data.php",
            minLength: 1
        });
    });
    </script>

</head>
<body>


<form method="get" action="http://localhost/staffsearch.php" >
<div class="ui-widget">
<input  id="txtLanguage" class="txtLanguage" type="text" name = "staff_search" autocomplete = "off" placeholder="enter staff's details here" style="width: 380px; height: 38px" onkeyup="showHint(this.value)">
</div>
</form>
<!--
<div >
    <input id="txtLanguage" class="txtLanguage"/>
</div>
-->

</body>
</html>
