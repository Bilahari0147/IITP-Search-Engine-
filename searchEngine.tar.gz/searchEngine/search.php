<!DOCTYPE html>
<html>

<head>
<style type="text/css">
.style9 {
	font-family: Andalus;
	font-size: large;
	font-weight: bold;
	font-style: normal;
	color: #0000FF;
}
</style>
</head>
 
<body> 
<form method="get" action="http://localhost/search.php" style="width: 1828px">

	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; web search&nbsp; </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 
	<input type = "text" name = "web_search" placeholder="enter web's details here" style="width: 373px; height: 25px" />  </form>	
  <br />
 <form method="get" action="http://localhost/search.php" style="width: 1828px">  
    <span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; student search</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 
	<input type = "text" name = "student_search" placeholder="enter student's details here" style="height: 28px; width: 379px" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</form>
  <br />
 <form method="get" action="http://localhost/employee.php" style="width: 1828px">
	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; employee search</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 
	<input type = "text" name = "employee_search" placeholder="enter employee's details here" style="width: 380px; height: 28px" /> </form> 
  <br />
 <form method="get" action="http://localhost/staffsearch.php" style="width: 1828px">
	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; staff search&nbsp; </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 
	<input type = "text" name = "staff_search" placeholder="enter staff's details here" style="width: 380px; height: 28px" /> 
    
</form>



<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

$result = mysqli_query($con,"SELECT * FROM search_student");
$i = 0;
while($row = mysqli_fetch_array($result))
  {if($row['name']==$_GET["web_search"]||$row['rollno']==$_GET["web_search"]||$row['branch']==$_GET["web_search"]||$row['roomno']==$_GET["web_search"]||$row['emailid']==$_GET["web_search"])
  {echo $row['rollno'] . " " . $row['name']." ".$row['branch']." ".$row['roomno']." ".$row['emailid'];
  echo "<br />";
   $i=1;
  }
  
  
  }
   if($i==0)
   {
   echo "requested data is does not exist";
   }

mysqli_close($con);
?>




</body>
</html> 