<!DOCTYPE html>
<html>

<head>
<style type="text/css">
.style9 {
	font-family: Andalus;
	font-size: large;
	font-weight: bold;
	font-style: normal;
	color: #0000FF;
}
</style>
</head>

<body>
<form method="get" action="http://localhost/search.php" style="width: 1828px">

	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; web search&nbsp; </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; 
	<input type = "text" name = "web_search" placeholder="enter web's details here" style="width: 373px; height: 25px" />  </form>	
  <br />
 <form method="get" action="http://localhost/search.php" style="width: 1828px">  
    <span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; student search</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 
	<input type = "text" name = "student_search" placeholder="enter student's details here" style="height: 28px; width: 379px" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</form>
  <br />
 <form method="get" action="http://localhost/employee.php" style="width: 1828px">
	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; employee search</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 
	<input type = "text" name = "employee_search" placeholder="enter employee's details here" style="width: 380px; height: 28px" /> </form> 
  <br />
 <form method="get" action="http://localhost/staffsearch.php" style="width: 1828px">
	<span class="style9">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; staff search&nbsp; </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp; 
	<input type = "text" name = "staff_search" placeholder="enter staff's details here" style="width: 380px; height: 28px" /> 
    
</form>

<!--
<script>
  (function() {
    var cx = '005662097621421639765:pjida91vz9o';
    var gcse = document.createElement('script');
    gcse.type = 'text/javascript';
    gcse.async = true;
    gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
        '//www.google.com/cse/cse.js?cx=' + cx;
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gcse, s);
  })();
</script>
<gcse:search></gcse:search>-->

<?php
$con=mysqli_connect("localhost","root","","search");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$x =str_word_count($_GET["employee_search"]);
$words = preg_split('/\s+|(?<=[,\.!\?])|(?=[,\.!\?])/',$_GET["employee_search"]) ;
$j=0;
$i = 0;
$arr=array();
while($j<$x)
{
$result = mysqli_query($con,"SELECT * FROM employee where firstname REGEXP '$words[$j]' or lastname REGEXP '$words[$j]' or designation REGEXP '$words[$j]' ");

while($row = mysqli_fetch_array($result))
  {//if($row['firstname']==$_GET["employee_search"]||$row['lastname']==$_GET["employee_search"]||$row['designation']==$_GET["employee_search"]||$row['phone']==$_GET["employee_search"]||$row['emailid']==$_GET["employee_search"])
  { $y=$row['id'];
    if(isset($arr[$y]) != -1)
   {echo  "<br />";
   echo  "<br />";
  
   //echo "<img border='0' src='staffimages/$row[firstname].jpg' alt='$row[firstname]' width='120' height='120' >";
   
   echo "<br/>";
   //echo "<a href=\"$row[profile]\">$row[firstname] $row[lastname]'s profile</a>";
   echo  "<br />";
   echo  "<br />";
   echo "name:"." Dr.".$row['firstname'] . " " . $row['lastname']." </br>designation:"." ".$row['designation']." </br>phone no: 0612255".$row['phone']." </br>emailid: ".$row['emailid']."@iitp.ac.in";
    
   echo "<br />";
   $arr[$row['id']]=-1;
   $i=1;}
  }
  
  
  }
  $j++;
 } 
   if($i==0)
   {
   echo "requested data is does not exist";
   }  
?>

<!--
<span class="style1">
<span class="style2"><br><span style="color:#E6FFE6;font-weight:500;font-size:20px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Advance Search
</span>
  
<div "width:800px">
 <form>
 
    <table>
	<tr><tr><tr><tr>
	<tr>
    <div class='selectBox'><th><span>Gender</span></th><th><span>: </span>
			<select class="selectOptions" name="gender"  onchange="showUser(designation.value,gender.value,age.value,depart.value)" >
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
				<option class="selectOption" value="male">male</option>
				<option class="selectOption" value="female">female</option>
							   
			</select></th>
		    </div></tr>
			
			
	<tr><tr><tr><tr><tr>
	<tr><tr>
    <div class='selectBox'><th><span>Age</span></th><th><span> :</span>
	    	<select class="selectOptions" name="age"onchange="showUser(designation.value,gender.value,age.value,depart.value)">
			    <option class="selectOption" value="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--select--&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp</option>
				<option class="selectOption" value="30">below 30</option>
				<option class="selectOption" value="40">31-40</option>
				<option class="selectOption" value="50">41-50</option>
                <option class="selectOption" value="60">51-60</option>
                <option class="selectOption" value="70">above 60</option>				
			</select></th>
		    </div></tr>	  
	
      </table>
	<br>
	
	
	
</form>	
 	    
</div>
</span>
</span>

-->

</body>
</html> 