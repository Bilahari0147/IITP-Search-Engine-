<?php
  // new dom object
function recursive($homelink) 
 {
 
 
 
 $dom = new DOMDocument();
   //$homelink = "http://172.16.1.3/~sriparna/";
  //load the html
    
  @$html = $dom->loadHTMLFile("$homelink");

  //discard white space 
  $dom->preserveWhiteSpace = false; 
 
  $tables = $dom->getElementsByTagName('table'); 
  $title  = $dom->getElementsByTagName('title'); 
  
$a = $dom->getElementsByTagName('a');
$i = 0;
//echo $a->length."<br/>";
for ($i; $i < $a->length; $i++) {
$attr1 = $a->item($i)->getAttribute('href');
$attr2 = $a->item($i)->textContent;
echo "<a href=\"$homelink"."$attr1\">$attr2</a>". "</br>";
$t = $homelink."/".$attr1;
echo $t;

echo "</br>";

if(($a->length)<=0||($attr1=="?C=N;O=D")||($attr1=="?C=M;O=A")||($attr1=="?C=S;O=A")||($attr1=="?C=D;O=A")||($attr1=="//"))
{
//break; 
 }
else
{
recursive($t);
}

 }
 
$text = $dom->textContent;
//echo $text;
 
}


$homelink = "http://172.16.1.3/~sriparna/";
 
 recursive($homelink);

?>
