<?php
$q=$_GET["q"];

$con = mysql_connect('localhost', 'root', '');
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("search", $con);

$sql="SELECT * FROM staff_new WHERE firstname = '".$q."'";

$result = mysql_query($sql);

echo "<table border='1'>
<tr>
<th>firstname</th>
<th>lastname</th>
<th>phone</th>
<th>emailid</th>
</tr>";

while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['firstName'] . "</td>";
  echo "<td>" . $row['lastName'] . "</td>";
  echo "<td>" . $row['phone'] . "</td>";
  echo "<td>" . $row['emailid'] . "</td>";
  echo "</tr>";
  }
echo "</table>";

mysql_close($con);
?>